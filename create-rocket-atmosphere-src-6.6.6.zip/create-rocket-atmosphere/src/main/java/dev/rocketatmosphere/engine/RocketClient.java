package dev.rocketatmosphere.engine;

import dev.rocketatmosphere.RocketAtmosphere;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;

/** Texturas dos fluidos (cliente): block/<nome>_still e block/<nome>_flow. */
@EventBusSubscriber(modid = RocketAtmosphere.MOD_ID, value = Dist.CLIENT, bus = EventBusSubscriber.Bus.MOD)
public final class RocketClient {
    private RocketClient() {}

    @SubscribeEvent
    public static void onRegisterClientExtensions(RegisterClientExtensionsEvent event) {
        for (RocketRegistries.RocketFluid fluid : RocketRegistries.FLUID_LIST) {
            try {
                event.registerFluidType(extensions(fluid.name()), fluid.type().get());
            } catch (IllegalStateException alreadyRegistered) {
                // Rede de seguranca, NAO e a correcao: so acontece se o jar tiver classes de versoes antigas
                // (dev.rocketatmosphere.raptor.*). A correcao real e reconstruir o jar sem elas.
                RocketAtmosphere.LOGGER.error("[RocketAtmosphere] extensoes de cliente de '{}' ja registradas por outra classe; "
                        + "o jar contem classes antigas (dev.rocketatmosphere.raptor.*). Reconstrua o jar a partir do projeto atual.",
                        fluid.name(), alreadyRegistered);
            }
        }
    }

    private static IClientFluidTypeExtensions extensions(String name) {
        ResourceLocation still = ResourceLocation.fromNamespaceAndPath(RocketAtmosphere.MOD_ID, "block/" + name + "_still");
        ResourceLocation flow = ResourceLocation.fromNamespaceAndPath(RocketAtmosphere.MOD_ID, "block/" + name + "_flow");
        return new IClientFluidTypeExtensions() {
            @Override
            public ResourceLocation getStillTexture() { return still; }

            @Override
            public ResourceLocation getFlowingTexture() { return flow; }
        };
    }
}
